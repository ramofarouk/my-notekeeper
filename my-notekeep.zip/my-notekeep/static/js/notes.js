$(".edit").click(function(){
  return confirm("Please create your document first.")
})
